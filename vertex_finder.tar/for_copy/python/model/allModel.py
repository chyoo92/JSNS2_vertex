from model.GNN1layer import *
from model.GNN2layer import *
